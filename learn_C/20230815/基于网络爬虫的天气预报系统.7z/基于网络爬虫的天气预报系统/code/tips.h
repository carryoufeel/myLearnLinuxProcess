#ifndef _TIPS_H_
#define _TIPS_H_

extern int tips(void);
#endif
