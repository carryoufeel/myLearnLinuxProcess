#ifndef _ASKHEAK_H_
#define _ASKHEAK_H_
extern int askhead(void);
#endif
