#ifndef _REALTIMEWEATHER_H_
#define _REALTIMEWEATHER_H_
extern int realtimeweather(void);
#endif
