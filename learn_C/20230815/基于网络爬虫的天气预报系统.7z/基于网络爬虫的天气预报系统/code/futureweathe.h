#ifndef _FUTUREWEATHE_H_
#define _FUTUREWEATHE_H_

extern int futureweather(void);
#endif
